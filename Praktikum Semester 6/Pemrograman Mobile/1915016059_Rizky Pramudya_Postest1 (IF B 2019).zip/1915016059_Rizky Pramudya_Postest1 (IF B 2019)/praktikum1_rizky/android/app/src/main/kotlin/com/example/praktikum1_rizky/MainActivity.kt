package com.example.praktikum1_rizky

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
