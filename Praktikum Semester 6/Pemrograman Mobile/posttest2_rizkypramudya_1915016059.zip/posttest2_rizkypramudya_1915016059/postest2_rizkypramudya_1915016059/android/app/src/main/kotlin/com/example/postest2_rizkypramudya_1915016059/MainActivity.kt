package com.example.postest2_rizkypramudya_1915016059

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
