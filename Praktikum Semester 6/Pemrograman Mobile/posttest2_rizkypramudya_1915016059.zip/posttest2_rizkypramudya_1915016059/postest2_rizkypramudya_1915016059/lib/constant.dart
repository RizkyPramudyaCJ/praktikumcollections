import 'package:flutter/material.dart';

class Palette {
  // ignore: prefer_const_constructors
  static Color background1 = Color.fromARGB(255, 126, 19, 189);
}
